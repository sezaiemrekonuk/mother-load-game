// A common interface for store objects, there isn't any methods yet.
// This is just a placeholder for future use.
// It is used to store the store objects in a list.
public interface Store { }
